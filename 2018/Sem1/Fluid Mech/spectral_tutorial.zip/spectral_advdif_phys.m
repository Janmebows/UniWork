% SPECTRAL_ADVDIF_PHYS solves the one-dimensional advection
% equation numerically using Fourier pseudospectral method in physical
% space.
%
% Adapted from SPECTRAL_ADV.
%
% Trent Mattner
% 26/04/2018

close all
clear all

set(groot, 'DefaultLineLineWidth', 1, ...
    'DefaultAxesLineWidth', 1, ...
    'DefaultAxesFontSize', 12, ...
    'DefaultTextFontSize', 12, ...
    'DefaultTextInterpreter', 'latex', ...
    'DefaultLegendInterpreter', 'latex', ...
    'DefaultColorbarTickLabelInterpreter', 'latex', ...
    'DefaultAxesTickLabelInterpreter','latex');

fileout = '../Figures/spec_advdiff_phys.eps';
f = @(x) exp(-100*(x-1).^2);
[x, t, u] = solve_advdif(256, 32, 1, 0.01, 20, f);

waterfall(x, t, u)
xlabel('$x$')
ylabel('$t$')
zlabel('$u(x,t)$')
box on
axis vis3d
set(gcf, 'units', 'inches', 'position', [4 4 4 4])
print(fileout, '-depsc')

function [x, t, u] = solve_advdif(N, nt, c, nu, T, f)

% SOLVE_ADVDIF solves the advection equation numerically on a
% 2*pi-periodic domain in physical space.
%
% Inputs:
%   N - number of collocation points.
%   nt - number of times for output.
%   c - advection velocity.
%   nu - diffusion coefficient.
%   T - final time.
%   f - function handle specifying IC.
%
% Outputs:
%   t - row vector containing output times.
%   x - row vector containing grid points.
%   u - matrix containing solution at t(j)
%       in row u(j,:).

% Set up grid and initial condition.

dx = 2*pi/N;
x = dx*(0:N-1);
ik = 1i*[0:N/2-1 0 -N/2+1:-1]';
k2 = [0:N/2 -N/2+1:-1]';
t = linspace(0, T, nt);
fh = fft(f(x));
        
% Numerical solution in physical space.

dudt = @(t, u) ifft(-(c*ik + nu*k2).*fft(u), 'symmetric');
[~, u] = ode45(dudt, t, f(x));
        
end
