% SPECTRAL_ADVDIF_PHYS solves the one-dimensional advection
% equation numerically using Fourier pseudospectral method in physical
% space.
%
% Adapted from SPECTRAL_ADV.
%
% Trent Mattner
% 26/04/2018

close all
clear all

set(groot, 'DefaultLineLineWidth', 1, ...
    'DefaultAxesLineWidth', 1, ...
    'DefaultAxesFontSize', 12, ...
    'DefaultTextFontSize', 12, ...
    'DefaultTextInterpreter', 'latex', ...
    'DefaultLegendInterpreter', 'latex', ...
    'DefaultColorbarTickLabelInterpreter', 'latex', ...
    'DefaultAxesTickLabelInterpreter','latex');

fileout = '../Figures/spectral_kdv.eps';
A = 25;
B = 18.75;
C = 12.5;
f = @(x) 3*A^2*sech(0.5*A*(x - 0.5)).^2 ...
    + 3*B^2*sech(0.5*B*(x - 1)).^2 + 3*C^2*sech(0.5*C*(x-2)).^2;
[x, t, u] = solve_kdv(250, 30, 0.008, f);

waterfall(x, t, u)
xlabel('$x$')
ylabel('$t$')
zlabel('$u(x,t)$')
box on
axis vis3d
set(gcf, 'units', 'inches', 'position', [4 4 4 4])
print(fileout, '-depsc')

function [x, t, u] = solve_kdv(N, nt, T, f)

% SOLVE_KDV solves the nonlinear KdV equation numerically on a
% 2*pi-periodic domain in physical space.
%
% Inputs:
%   N - number of collocation points.
%   nt - number of times for output.
%   T - final time.
%   f - function handle specifying IC.
%
% Outputs:
%   t - row vector containing output times.
%   x - row vector containing grid points.
%   u - matrix containing solution at t(j)
%       in row u(j,:).

% Set up grid and initial condition.

dx = 2*pi/N;
x = dx*(0:N-1);
ik = 1i*[0:N/2-1 0 -N/2+1:-1]';
ik3 = ik.^3;
t = linspace(0, T, nt);
fh = fft(f(x));

% Numerical solution in physical space.

[~, u] = ode45(@kdv, t, f(x));

    function dudt = kdv(t, u)
        
        uh = fft(u);
        ux = ifft(ik.*uh, 'symmetric');
        uxxx = ifft(ik3.*uh, 'symmetric');
        dudt = -u.*ux - uxxx;
        
    end

end
